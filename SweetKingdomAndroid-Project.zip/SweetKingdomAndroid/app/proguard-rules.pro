# No custom shrinking rules required for this initial release.
