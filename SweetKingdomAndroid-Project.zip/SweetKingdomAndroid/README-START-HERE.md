# Sweet Kingdom Android — Starter Project

This is an Android Studio project wrapper around the supplied Sweet Kingdom HTML/CSS/JavaScript game.

## Included
- The original game files bundled in `app/src/main/assets/`
- Android WebView loading local assets through `WebViewAssetLoader`
- JavaScript + DOM storage enabled so game progress can persist locally
- Portrait orientation and immersive full-screen presentation
- App launcher vector icon
- Remote Google Fonts import removed; system-font fallbacks are used so the game does not need internet to load fonts
- No INTERNET permission is declared

## Build requirements
- Android Studio with Android SDK Platform 36 installed
- JDK 17
- Internet access during the first Gradle sync to download Gradle and Android dependencies. The *game itself* is intended to run offline after installation.

## Open and build
1. Extract this folder on a computer.
2. Open `SweetKingdomAndroid` in Android Studio.
3. Let Gradle sync. If Android Studio asks to install SDK Platform 36, accept.
4. Run on a real Android device or emulator and test in Airplane mode.
5. To make a test APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. To prepare a Play Store release: **Build > Generate Signed Bundle / APK > Android App Bundle**. Create and securely back up your signing key.

## Package details
- Application ID: `com.sohailshafiq.sweetkingdom`
- Version: `1.0.0` (versionCode 1)
- Target SDK: 36

## Important notes before publishing
- This is a starter project; it has not been compiled or device-tested in this environment because Android SDK/Gradle build tools are not installed here.
- Test gameplay, persistence after force-close/reopen, sound, back-button behavior, small screens, and Android versions before release.
- The app currently uses the existing game's generated Web Audio effects and localStorage save. Saved browser progress will not transfer from Chrome to the installed app.
- Google Play requires a Play Console account, compliant store listing, app content/data declarations, privacy policy if applicable, and required testing. Verify current Play Console requirements before submission.
- Do not publish until all runtime and offline tests pass.

## If Android Studio reports a missing Gradle wrapper
This archive does not bundle the Gradle wrapper JAR. The easiest reliable setup is:
1. In Android Studio choose **New Project > Empty Views Activity**, Kotlin, minimum SDK 23, package `com.sohailshafiq.sweetkingdom`.
2. Keep the generated project's `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`, and wrapper properties.
3. Copy this archive's `app/src/main/assets/` folder into the generated app's `app/src/main/assets/`.
4. Copy `MainActivity.kt` into the matching package path, replace the generated `AndroidManifest.xml` and `res/values/styles.xml`, and copy `res/drawable/ic_sweet_kingdom.xml`.
5. Add the dependencies from this project's `app/build.gradle.kts` to the generated app module, and set `compileSdk = 36`, `targetSdk = 36`, and `minSdk = 23`.
6. Sync Gradle and build the APK.
